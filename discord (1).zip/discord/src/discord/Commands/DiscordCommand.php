<?php

namespace discord\Commands;

use discord\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\lang\Translatable;
use pocketmine\player\Player;

class DiscordCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("discord", "avoir le ds", "/discord");
        $this->setPermission("discord.cmd");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        $sender->sendMessage(Main::PREFIX . "Le discord du serveur est discord.gg/");
        }
    }